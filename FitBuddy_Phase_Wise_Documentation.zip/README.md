# FitBuddy AI - Phase Wise Documentation

This folder contains the phase-wise documentation for the FitBuddy AI project.

## Team
- Madhumitha M
- Sarika P
- Vaishnavi K
- Jeeva M

## Phases
1. Brainstorming & Ideation
2. Requirement Analysis
3. Project Design
4. Project Planning
5. Project Development
6. Project Testing
7. Project Documentation
8. Project Demonstration
